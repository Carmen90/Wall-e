package tp.pr2;

public enum Rotation {
	LEFT, RIGHT, UNKNOWN
}
