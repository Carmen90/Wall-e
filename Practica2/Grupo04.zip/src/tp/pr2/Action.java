package tp.pr2;

public enum Action {
	HELP, MOVE, OPERATE, PICK, QUIT, SCAN, TURN, UNKNOWN
}
